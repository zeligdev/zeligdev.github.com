#' Describe the \\model\\ Zelig Model
#' @param ... ignored parameters
#' @return a list specifying author, title, etc. information
#' @export
describe.\\model\\ <- function(...) {
  list(
       authors = "",
       text = ""
       )
}
